san_total=0
temp=[]
guj_total=0
sci_total=0
soc_total=0
math_total=0
eng_total=0
file = open("test.txt",'r')
data=file.readline()
while data:
    if 'that' in data:
        name = file.readline()
        print(name)
    try:
        if 'ENGLISH' in data:
            eng= data.split()
            for i in eng:
                for x in i:
                    if(x.isnumeric()):
                        temp.append(i)
                        break
            print("Eng Marks:",temp,"\n")
            eng_inter=temp[1]
            eng_exter=temp[2]
            eng_total=temp[3]
            print("eng_inter",eng_inter)
            print("eng_exter",eng_exter)
            print("eng_total",eng_total)
            temp=[]
        
        if 'MATHEMATICS' in data:
            math= data.split()
            for i in math:
                for x in i:
                    if(x.isnumeric()):
                        temp.append(i)
                        break
            print("Meth Marks:",temp,"\n")
            math_inter=temp[1]
            math_exter=temp[2]
            math_total=temp[3]
            print("math_inter",math_inter)
            print("math_exter",math_exter)
            print("math_total",math_total)
            temp=[]
            
        if 'SOCIAL' in data:
            soc= data.split()
            for i in soc:
                for x in i:
                    if(x.isnumeric()):
                        temp.append(i)
                        break
            print("Soc Marks:",temp,"\n")
            soc_inter=temp[1]
            soc_exter=temp[2]
            soc_total=temp[3]
            print("soc_inter",soc_inter)
            print("soc_exter",soc_exter)
            print("soc_total",soc_total)
            temp=[]
                    
        if 'TECHNO' in data:
            sci= data.split()
            for i in sci:
                for x in i:
                    if(x.isnumeric()):
                        temp.append(i)
                        break
            print("Sci Marks:",temp,"\n")
            sci_inter=temp[1]
            sci_exter=temp[2]
            sci_total=temp[3]
            print("sci_inter",sci_inter)
            print("sci_exter",sci_exter)
            print("sci_total",sci_total)
            temp=[]
                    
        if 'GUJARATI' in data:
            guj= data.split()
            for i in guj:
                for x in i:
                    if(x.isnumeric()):
                        temp.append(i)
                        break
            print("Guj Marks:",temp,"\n") 
            guj_inter= temp[1]
            guj_exter= temp[2]
            guj_total= temp[3]
            print("guj_inter",guj_inter)
            print("guj_exter",guj_exter)
            print("guj_total",guj_total)
            temp=[]
                    
        if 'SANSKRIT' in data:
            san= data.split()
            for i in san:
                for x in i:
                    if(x.isnumeric()):
                        temp.append(i)
                        break
            print("San Marks:",temp,"\n")
            san_inter=temp[1]
            san_exter=temp[2]
            san_total=temp[3]
            print("san_inter",san_inter)
            print("san_exter",san_exter)
            print("san_total",san_total)
            temp=[]
        data=file.readline() 
    except:
        pass 
    