from django.db import models

# Create your models here.

class Data(models.Model):
    name= models.CharField(max_length=50)
    eng_inter = models.CharField(max_length=50)
    eng_exter = models.CharField(max_length=10)
    eng_total=models.CharField(max_length=10)
    san_inter = models.CharField(max_length=50)
    san_exter = models.CharField(max_length=10)
    san_total=models.CharField(max_length=10)
    math_inter = models.CharField(max_length=50)
    math_exter = models.CharField(max_length=10)
    math_total=models.CharField(max_length=10)
    guj_inter = models.CharField(max_length=50)
    guj_exter = models.CharField(max_length=10)
    guj_total=models.CharField(max_length=10)
    sci_inter = models.CharField(max_length=50)
    sci_exter = models.CharField(max_length=10)
    sci_total=models.CharField(max_length=10)
    soc_inter = models.CharField(max_length=50)
    soc_exter = models.CharField(max_length=10)
    soc_total=models.CharField(max_length=10)
    File=models.FileField(upload_to='media/images/')

    def __str__(self):
        return self.name