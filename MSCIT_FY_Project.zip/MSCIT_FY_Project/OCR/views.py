from django.shortcuts import render

from .models import *

from PIL import Image
import pytesseract


# Create your views here.
def index(request):
	if request.method=="POST":
		
		pytesseract.pytesseract.tesseract_cmd="Tesseract-OCR/tesseract.exe"

		File=request.FILES['File']
		image = Image.open(File)
		image_text = pytesseract.image_to_string(image)

		print("imtotxt")

		f = open("test.txt",'w')
		f.write(image_text)
		f.close()

		print("write")

		san_total=0
		temp=[]
		guj_total=0
		sci_total=0
		soc_total=0
		math_total=0
		eng_total=0
		name=""
		file = open("test.txt",'r')
		data=file.readline()
		while data:
			if 'that' in data:
				name = file.readline()
				print(name)
			try:
				if 'ENGLISH' in data:
					eng= data.split()
					for i in eng:
						for x in i:
							if(x.isnumeric()):
								temp.append(i)
								break
					print("Eng Marks:",temp,"\n")
					eng_inter=temp[1]
					eng_exter=temp[2]
					eng_total=temp[3]
					temp=[]
        
				if 'MATHEMATICS' in data:
					math= data.split()
					for i in math:
						for x in i:
							if(x.isnumeric()):
								temp.append(i)
								break
					print("Meth Marks:",temp,"\n")
					math_inter=temp[1]
					math_exter=temp[2]
					math_total=temp[3]
					temp=[]
            
				if 'SOCIAL' in data:
					soc= data.split()
					for i in soc:
						for x in i:
							if(x.isnumeric()):
								temp.append(i)
								break
					print("Soc Marks:",temp,"\n")
					soc_inter=temp[1]
					soc_exter=temp[2]
					soc_total=temp[3]
					temp=[]
                    
				if 'TECHNO' in data:
					sci= data.split()
					for i in sci:
						for x in i:
							if(x.isnumeric()):
								temp.append(i)
								break
					print("Sci Marks:",temp,"\n")
					sci_inter=temp[1]
					sci_exter=temp[2]
					sci_total=temp[3]
					temp=[]
                    
				if 'GUJARATI' in data:
					guj= data.split()
					for i in guj:
						for x in i:
							if(x.isnumeric()):
								temp.append(i)
								break
					print("Guj Marks:",temp,"\n")
					guj_inter= temp[1]
					guj_exter= temp[2]
					guj_total= temp[3]
					temp=[]
                    
				if 'SANSKRIT' in data:
					san= data.split()
					for i in san:
						for x in i:
							if(x.isnumeric()):
								temp.append(i)
								break
					print("San Marks:",temp,"\n")
					san_inter=temp[1]
					san_exter=temp[2]
					san_total=temp[3]
					temp=[]
				data=file.readline()

			except:
				pass	

		obj=Data.objects.create(name=name,eng_inter=eng_inter,eng_exter=eng_exter,eng_total=eng_total,san_inter=san_inter,san_exter=san_exter,san_total=san_total,math_inter=math_inter,
			math_exter =math_exter, math_total=math_total,guj_inter=guj_inter,guj_exter=guj_exter,guj_total=guj_total,sci_inter=sci_inter,sci_exter =sci_exter,sci_total=sci_total,
			soc_inter=soc_inter,soc_exter=soc_exter,soc_total=soc_total,File=File)
		objs=Data.objects.all()
		context={'objs':objs}
		return render(request,"OCR/view.html",context)
	else:
		return render(request,"OCR/index.html")
		

def view(request):
	if request.method=="POST":
		edit_id=request.POST["id"]
		objs=Data.objects.get(id=edit_id)
		context={'objs':objs}
		return render(request,"OCR/edit.html",context)
	else:
		objs=Data.objects.all()
		context={'objs':objs}
		return render(request,"OCR/view.html",context)

def edit(request):
	if request.method=="POST":
		edit_id=request.POST["id"]
		objs=Data.objects.get(id=edit_id)
		objs.eng_inter=request.POST['eng_inter']
		objs.eng_exter=request.POST['eng_exter']
		objs.eng_total=request.POST['eng_total']
		objs.math_inter=request.POST['math_inter']
		objs.math_exter=request.POST['math_exter']
		objs.math_total=request.POST['math_total']
		objs.soc_inter=request.POST['soc_inter']
		objs.soc_exter=request.POST['soc_exter']
		objs.soc_total=request.POST['soc_total']
		objs.sci_inter=request.POST['sci_inter']
		objs.sci_exter=request.POST['sci_exter']
		objs.sci_total=request.POST['sci_total']
		objs.guj_inter=request.POST['guj_inter']
		objs.guj_exter=request.POST['guj_exter']
		objs.guj_total= request.POST['guj_total']
		objs.san_inter=request.POST['san_inter']
		objs.san_exter=request.POST['san_exter']
		objs.san_total=request.POST['san_total']
		
		objs.save()
		objs=Data.objects.all()
		context={'objs':objs}
		return render(request,"OCR/view.html",context)
	else:
		pass